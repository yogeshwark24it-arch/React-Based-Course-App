import React from "react";
import "./App.css";
import CourseCard from "./CourseCard";

function App() {
  return (
    <div className="app">
      <h1>Online Learning Courses</h1>

      <div className="course-container">
        <CourseCard />
      </div>
    </div>
  );
}

export default App;