import React from "react";

function CourseCard() {
  return (
    <>
      <div className="card">
        <img src="https://picsum.photos/300/180?1" alt="Course" className="course-image" />
        <h2>React JS for Beginners</h2>
        <p><strong>Instructor:</strong> John Smith</p>
        <p><strong>Duration:</strong> 8 Weeks</p>
        <p><strong>Rating:</strong> ⭐ 4.8</p>
        <p><strong>Fee:</strong> $49</p>
      </div>

      <div className="card">
        <img src="https://picsum.photos/300/180?2" alt="Course" className="course-image" />
        <h2>Python Programming</h2>
        <p><strong>Instructor:</strong> David Miller</p>
        <p><strong>Duration:</strong> 10 Weeks</p>
        <p><strong>Rating:</strong> ⭐ 4.7</p>
        <p><strong>Fee:</strong> $59</p>
      </div>

      <div className="card">
        <img src="https://picsum.photos/300/180?3" alt="Course" className="course-image" />
        <h2>Web Development</h2>
        <p><strong>Instructor:</strong> Sarah Wilson</p>
        <p><strong>Duration:</strong> 12 Weeks</p>
        <p><strong>Rating:</strong> ⭐ 4.9</p>
        <p><strong>Fee:</strong> $69</p>
      </div>

      <div className="card">
        <img src="https://picsum.photos/300/180?4" alt="Course" className="course-image" />
        <h2>Java Programming</h2>
        <p><strong>Instructor:</strong> Michael Brown</p>
        <p><strong>Duration:</strong> 6 Weeks</p>
        <p><strong>Rating:</strong> ⭐ 4.6</p>
        <p><strong>Fee:</strong> $39</p>
      </div>

      <div className="card">
        <img src="https://picsum.photos/300/180?5" alt="Course" className="course-image" />
        <h2>Data Science</h2>
        <p><strong>Instructor:</strong> Emily Davis</p>
        <p><strong>Duration:</strong> 14 Weeks</p>
        <p><strong>Rating:</strong> ⭐ 4.9</p>
        <p><strong>Fee:</strong> $79</p>
      </div>

      <div className="card">
        <img src="https://picsum.photos/300/180?6" alt="Course" className="course-image" />
        <h2>UI/UX Design</h2>
        <p><strong>Instructor:</strong> Sophia Lee</p>
        <p><strong>Duration:</strong> 9 Weeks</p>
        <p><strong>Rating:</strong> ⭐ 4.8</p>
        <p><strong>Fee:</strong> $55</p>
      </div>
    </>
  );
}

export default CourseCard;